const Notfound = () => {
  return <div>잘못된 페이지입니다.</div>;
};

export default Notfound;
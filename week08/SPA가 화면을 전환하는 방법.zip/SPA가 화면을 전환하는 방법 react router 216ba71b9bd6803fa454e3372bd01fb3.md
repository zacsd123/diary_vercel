# SPA가 화면을 전환하는 방법 : react router

### Routing

Routing이란 사용자가 요청한 URL에 따라 알맞은 페이지를 보여주는 것으로,  네트워크에서 경로를 선택하는 프로세스를 의미한다. 즉, 다양한 주소의 요청이 들어왔을 때 각각 맞는 콘텐츠로 이동 시켜주는 작업을 말한다.

MPA와 SPA에서의 Routing

1. MPA 
    
     서버가 여러 개의 페이지로 구성되어 있는 어플리케이션을 말한다. 클라이언트(브라우저)가 서버로 URL을 통해 페이지 요청을 보내면 서버는 클라이언트에게 요청 url에 맞는 페이지를 반환하여 표출한다. 
    
     페이지 이동을 할 때 화면이 깜빡이면서 페이지가 이동 되는 것이 MPA의 특징이다. MPA 라우팅은 초반에는 빠르지만, 페이지 이동마다 전체 리로드가 필요해서 끊김이 있을 수 있다. 
    
2. SPA
    
     단일 페이지로 구성되어 있기 때문에, 클라이언트가 서버로 URL을 통해 페이지 요청을 했을 때 하나의 HTML 파일만 로딩된다. 이후에는 JavaScript가 브라우저 내에서 URL 변경을 감지하고 해당 URL에 맞는 컴포넌트만 부분 렌더링 한다. 
    
     SPA 방식을 React에서는 React Router를 이용하여 URL에 맞는 페이지 이동을 하게 되는데, 서버로 url 요청을 하여 페이지를 이동하는 것이 아니라, 클라이언트 React app에서 요청 URL에 맞는 페이지로 업데이트를 해주게 된다.
    

### React Router

react 앱에서 페이지처럼 동작하는 URL 기반의 라우팅을 구현할 수 있게 해주는 라이브러리. 즉, URL은 바뀌지만 페이지를 새로고침하지 않고도 화면을 바꿔주는 역할을 한다.

React는 SPA라서 기본적으로 하나의 HTML만 있다. 그런데 사용자가 다른 페이지로 이동하는 것이 필요하기 때문에, React Router는 브라우저 주소(URL)를 감지하여 그에 따라 보여줄 컴포넌트를 바꿔주는 역할을 한다. 

<BrowerRouter> : 라우팅 기능을 사용할 수 있게 앱 전체를 감싸주는 컴포넌트 실제 브라우저 주소를 하용함.(/Home 등)

```jsx
import { BrowserRouter } from "react-router-dom";

<BrowserRouter>
  <App />
</BrowserRouter>

```

<Routes>와 <Route>

Routes : 여러 개의 경로 설정을 담는 껍데기

Route : 하나의 URL과 컴포넌트를 연결

```jsx
import { Routes, Route } from "react-router-dom";
import Home from './Home';
import New from './New';

<Routes>
  <Route path="/" element={<Home />} />
  <Route path="/new" element={<New/>} />
</Routes>
```

<Link> : 페이지를 이동할 때 사용

기존의 <a href=”…”>는 페이지를 새로고침하기 때문에, SPA에서 쓰지 않는다. 대신 React Router에서는 <Link>를 사용한다.

```jsx
import { Link } from "react-router-dom";

<Link to="/New">New Page</Link>
```

useNavigate() : 자바스크립트로 페이지 이동

```jsx
import { useNavigate } from 'react-router-dom';

const MyComponent = () => {
  const navigate = useNavigate();
  
  const goToNew = () => {
    navigate('/about');
  };

  return <button onClick={goToNew}>New로 이동</button>;
};
```

동적 라우팅(파라미터 받기) 

```jsx
<Route path="/diary/:id" element={<Diary />} />
```

:id 자리에는 아무 값이나 들어갈 수 있다. 

Diary 컴포넌트에서는 useParams()로 값을 꺼낸다.

```jsx
import { useParams } from "react-router-dom";

const Diary = () => {
  const params = useParams();

  return <div>{params.id}번 일기입니다</div>;
};

export default Diary;

```

요약

| 개념 | 설명 |
| --- | --- |
| `BrowserRouter` | 라우팅 기능을 전체에 적용하는 껍데기 |
| `Routes`, `Route` | URL과 컴포넌트를 연결해주는 매핑 설정 |
| `Link` | 새로고침 없이 URL 이동 |
| `useNavigate()` | JS로 페이지 전환 |
| `useParams()` | 동적 URL에서 값 추출 |
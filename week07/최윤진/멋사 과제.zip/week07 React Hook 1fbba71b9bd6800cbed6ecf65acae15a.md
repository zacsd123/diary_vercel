# week07 React Hook

과제

React에서 사용하는 hook이 무엇인지,
hook의 종류에는 어떤 것들이 있는지,
우리가 여태 배운 hook은 어떻게 쓰는지
각자 노션에 정리

### 리액트 훅(React Hook)이란?

React Hook이란, 함수형 컴포넌트(Functional Component)에서 사용되는 몇 가지 기술들을 일컫는다. 리액트 훅은 함수형 컴포넌트가 클래스형 컴포넌트(Class Component)의 기능을 사용할 수 있도록 해주며, 대표적인 예로는 useState, useEffect 등이 존재한다. 

### React Hook의 규칙

1. 리액트 Hook은 반복문, 조건문 혹은 중첩된 함수 내에서 호출하면 안 되며, 반드시 최상위(at the Top Level)에서만 Hook을 호출해야 한다. 또한 Hook은 렌더링 시 항상 동일한 순서로 호출 되어야 한다.
2. Hook은 React함수 내에서만 호출해야 한다. 즉, 리액트 Hook은 함수형 컴포넌트에서 호출해야 하며, 추가적으로 custom hooks에서 또한 호출이 가능하다.

### 대표적인 React Hook과 사용 방법

1. useState
    
    useState는 Component에서 상태(state) 값을 추가할 때 사용되며, 클래스형 컴포넌트(Class Component)에서만 사용 가능하던 State를 함수형 컴포넌트(Functional Component)에서도 사용 가능하도록 한 대표적인 기능이다. 
    
    선언은 const[변수명, 상태를 업데이트 할 함수명] = useState(초기값)을 통해 할 수 있으며 useState로 선언된 변수 state가 변할 때마다 페이지를 리렌더링 시키게 된다. 이때 (상태를 업데이트 할 함수명)은 비동기로 처리 되는데, 이는 함수가 호출 될 때마다 화면을 다시 렌더링 하기 때문에 성능적인 문제가 발생 할 수 있기 때문이다. 
    
2. useEffect
    
    useEffect는 화면이 렌더링 될 때마다, 특정 작업을 실행 할 수 있도록 하는 Hook이다. 이를 통해 함수형 컴포넌트에서 Side Effect를 사용할 수 있게 됐을 뿐만 아니라, 클래스형 컴포넌트(Class Compotnent)의 Life Cycle Method에서 사용되는 componentDidMount(최초 렌더링)와 componentDidUpdate(렌더링 후 업데이트)를 합친 형태로, 페이지가 렌더링 될 때 변화된 값으로 인해 바뀌어야 할 화면의 데이터들을 처리해준다.
    
    선언은 useEffect(()⇒{익명함수}, [])이며 매개변수는 보이는 것과 같이 익명함수와 빈 배열이다. 뒤의 빈 배열의 종류에 따라 렌더링의 횟수를 조절할 수 있다. 
    
    1. []= 최초 렌더링(마운트) 될 때 한 번만 실행된다.
    2. [상태값1, 상태값2 ,,] = 선언한 상태값들이 업데이트 될 때만 실행된다.
    3. 생략 = 리렌더링 시마다 반드시 실행된다.

1. useReducer 
    
    useReducer는 이 전 상태(state)와 Action을 결합하여, 새로운 상태값(state)를 만든다. 일반적으로 React에서 상태 관리를 위해 사용하는 Hook은 useSate이지만, 좀 더 복잡한 상태 관리가 필요한 경우 reducer를 사용 할 수 있다. 
    
    선언은 const [변수명, dispatch] = useReducer[reducer, 초기값, 초기 함수] 이다. 
    
    1. dispatch = reducer 함수를 실행시키며, action 객체 (=어떠한 행동이지를 나타내는 type 속성과 관련 데이터로 구성)를 인자로 받으며, action 객체를 통해 컴포넌트 내에서 상태값(state)의 업데이트를 일으킨다.
    2. reducer = dispatch를 통해 실행되며, 컴포넌트 외부에서 상태 값(state)를 업데이트 한다. 함수의 인자로는 state와 action을 받으며 이를 통해 새로운 state를 반환한다. 

1. useRef
    
    useRef은 렌더링과 관계없이 값을 저장할 수 있는 공간을 만들어주는 React Hook이다. Dom 요소를 직접 참조하거나, 렌더링과 상관없는 변수를 유지하고 싶을 때 사용한다. 
    
    선언은 const 변수명 = useRef(초기값); 이다.
    
    useRef()는 상태나 배열이 아니라 current라는 key를 가진 객체 하나를 반환한다.
    

### Todo List 에서 사용한 Hook

1. App.jsx
    1. useState
        
        const [todos, setTodos] = useState(mockData);
        
        todo라는 상태(state) 값을 선언하고 setTodos를 이용해서 해당 값을 변경할 수 있게 해준다.
        
        React는 값이 바뀌어도 자동으로 화면(UI)이 갱신되지 않는다. 
        
        useState를 사용하면 상태 값이 바뀔 때마다 자동으로 컴포넌트를 다시 렌더링 해준다. 즉, setTodos()로 상태를 바꾸면 화면도 함께 바뀐다.
        
    2. useRef
        
        const idRef = useRef(3);
        
        렌더링과 관계없는 “값 저장용 변수”를 만들 때 사용한다.
        
        여기서는 다음에 새로 추가될 todo의 id값을 기억하는 데 쓰고있다.
        
        useState로 id를 관리하면 값이 바뀔 때마다 컴포넌트가 리렌더링 된다. 하지만 idRef.current는 바뀌어도 화면에 영향을 주지 않는다. 
        
        화면에 표시되지 않는 단순한 값을 저장할 때는 useRef가 효율적이고, 화면을 갱신해야 하는 값은 useState를 사용한다.
        

1. Editor.jsx
    1. useState
        
        const [content, setContent] = useState("");
        
        사용자가 <input>에 입력한 텍스트 상태값을 관리한다. 
        
        입력창에 글자가 바뀔 때마다 setContent()로 상태를 업데이트 하고, 이 상태값(content)이 다시 input의 value로 연결돼 있다. 
        
        입력값을 React가 직접 제어할 수 있게 만들기 위해 사용한다. 예를들어 입력 후 setContent(””)하면 입력창이 자동으로 비워진다.
        
    2. useRef
        
        const contentRef = useRef();
        
        if (content === "") {
        contentRef.current.focus();  //커서가 input 창으로 감.
        
        …
        }
        
        특정 Dom 요소(input)에 직접 접근할 수 있게 해준다.
        
        여기서는 content가 비어있을 때, 입력창에 포커스를 주기 위해 사용한다.
        
        focus(), scrollIntoView() 같은 Dom조작이 필요할 땐 useRef를 써야한다. 직접 input 태그에 접근해서 커서 위치를 제어하거나, 포커스를 줄 수 있다.
        
2. List.jsx
    1. useState
        
        const [search, setSearch] = useState("");
        
        <input
        value={search}
        onChange={onChangeSearch}
        placeholder="검색어를 입력하세요"
        />
        
        사용자가 검색창에 입력한 텍스트 값을 상태로 관리한다.
        
        즉, search는 현재 검색어 값이고, setSearch()는 그 값을 업데이트 하는 함수이다. 
        
        위의 input을 보면 input 박스는 search 값을 반영해서 보여주고, 사용자가 뭔가 입력할 때마다 onChangeSearch가 실행돼서 상태가 업데이트 된다.
        

+

### React Component 종류

리액트 컴포넌트는 함수형 컴포넌트(Functional Component)와 클래스형 컴포넌트(Class Component)로 나뉜다.

리액트 초기에는 일반적으로 함수형 컴포넌트(Functional Component)를 사용하였으나, 값의 상태를 관리 혹은 Life Cycle Method(생명 주기 = 컴포넌트가 생성되고 사라지는 과정이 존재 할 때)를 사용하여야 할 때에만 클래스형 컴포넌트 (Class Component)를 사용하였다. 

함수형 컴포넌트가 사용된 이유는 아래와 같은 클래스형 컴포넌트의 대표적인 단점 때문이다.

1. 코드의 구성이 어렵고 Component의 재사용성이 떨어진다.
2. 컴파일 단계에서 코드 최적화를 어렵게 한다.
3. 최신 기술의 적용이 효과적이지 않다.

이러한 클래스형 컴포넌트(Class Component )의 단점을 보완하여, 함수형 컴포넌트(Functional Component)를 사용할 수 있도록 등장한 것이 바로 React Hook(리액트 훅)이다.